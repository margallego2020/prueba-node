// ************ Require's ************
const express = require('express');
const router = express.Router();

// ************ Controller Require ************
const mainController = require('../controllers/mainController');

/* Quiten el comentario y editen según el enunciado

router.???('/', mainController.index); 
router.???('/search', mainController.search);  

*/

module.exports = router;
